package ActividadCodoACodo;

import java.util.Scanner;

public class Ejercicio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String EntradaNombre;
		String EntradaApellido;
		int EntradaEdad;
		String EntradaEditorCodigo;
		String EntradaSO;
		
		Scanner Entrada = new Scanner (System.in);
		
		System.out.println("Ingresar nombre: ");
		EntradaNombre = Entrada.next();
		
		System.out.println("Ingresar apellido: ");
		EntradaApellido = Entrada.next();
		
		System.out.println("Ingresar edad: ");
		EntradaEdad = Entrada.nextInt();
		
		System.out.println("Ingresar editor de c�digo: ");
		EntradaEditorCodigo = Entrada.next();
		
		System.out.println("Ingresar sistema operativo: ");
		EntradaSO = Entrada.next();
		
		
		System.out.println("Los datos ingresados son: ");
		System.out.println("Nombre y apellido: " + EntradaNombre +" "+EntradaApellido);
		System.out.println("edad: "+EntradaEdad);
		System.out.println("Editor de codigo que utiliza es: "+EntradaEditorCodigo);
		System.out.println("Sistema operativo que utiliza es: "+EntradaSO);
		
		Entrada.close();
	}

}
